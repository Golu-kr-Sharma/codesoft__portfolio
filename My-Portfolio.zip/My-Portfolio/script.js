const toggleBtn = document.getElementById("modeToggle");
const body = document.body;
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");

toggleBtn.addEventListener("click", () => {
    body.classList.toggle("dark");
    body.classList.toggle("light");
    toggleBtn.textContent = body.classList.contains("dark") ? "☀️" : "🌙";
});

// Mobile menu toggle
menuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("show");
});

// Fade-in effect on scroll
const fadeElements = document.querySelectorAll(".fade-in");
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show");
        }
    });
});
fadeElements.forEach(el => observer.observe(el));
